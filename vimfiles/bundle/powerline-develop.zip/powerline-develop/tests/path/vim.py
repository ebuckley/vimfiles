# vim:fileencoding=utf-8:noet
from tests import vim


globals().update(vim._init())
